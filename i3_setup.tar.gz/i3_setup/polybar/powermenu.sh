#!/bin/bash

case "$1" in
shutdown)
	systemctl poweroff
	;;
reboot)
	systemctl reboot
	;;
suspend)
	systemctl suspend
	;;
logout)
	# Replace this with the command to logout from your window manager
	i3-msg exit
	;;
*)
	echo "Usage: $0 {shutdown|reboot|suspend|logout}"
	exit 2
	;;
esac

exit 0
